<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_With');

if (\false) {
    class WithTokenParser extends \Twig_TokenParser_With
    {
    }
}
