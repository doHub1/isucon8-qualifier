<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_BitwiseAnd');

if (\false) {
    class BitwiseAndBinary extends \Twig_Node_Expression_Binary_BitwiseAnd
    {
    }
}
