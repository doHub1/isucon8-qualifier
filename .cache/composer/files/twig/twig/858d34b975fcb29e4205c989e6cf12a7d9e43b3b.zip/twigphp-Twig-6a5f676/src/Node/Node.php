<?php

namespace Twig\Node;

class_exists('Twig_Node');

if (\false) {
    class Node extends \Twig_Node
    {
    }
}
