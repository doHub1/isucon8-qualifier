<?php

namespace Twig;

class_exists('Twig_TokenStream');

if (\false) {
    class TokenStream extends \Twig_TokenStream
    {
    }
}
