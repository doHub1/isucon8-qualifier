<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Set');

if (\false) {
    class SetTokenParser extends \Twig_TokenParser_Set
    {
    }
}
