<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_And');

if (\false) {
    class AndBinary extends \Twig_Node_Expression_Binary_And
    {
    }
}
