<?php

namespace Twig\Node;

class_exists('Twig_Node_ForLoop');

if (\false) {
    class ForLoopNode extends \Twig_Node_ForLoop
    {
    }
}
